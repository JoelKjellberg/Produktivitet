import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import { Button } from 'react-native-paper';
import Page2 from './Page2';
import Page3 from './Page3';
import Page4 from './Page4';

const Stack = createStackNavigator();

function App() {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Bara för mig
      </Text>
      <Button mode="contained" onPress={() => navigation.navigate('Page2')}>
        En knapp
      </Button>
    </View>
  );
}

function Navigator() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="App" component={App} />
      <Stack.Screen name="Page2" component={Page2} />
      <Stack.Screen name="Page3" component={Page3} />
      <Stack.Screen name="Page4" component={Page4} />
    </Stack.Navigator>
  )
}

export default function Root() {
  return (
    <NavigationContainer>
      <Navigator />
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'topcenter',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf',
    padding: 8,

  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
